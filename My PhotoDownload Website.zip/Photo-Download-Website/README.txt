# Photo Download website

A beginner-friendly static website with:
- Searchable, category-filtered sample photo gallery
- Image URL preview
- Download button with CORS-aware fallback
- Responsive mobile/desktop layout
- Basic SEO metadata

## Run on your computer
1. Extract `Photo-Download-Website.zip`.
2. Open the folder in VS Code or another editor.
3. Open `index.html` in Chrome.

## Publish with GitHub Pages
1. Create/sign in to a GitHub account.
2. Create a public repository named `photo-download`.
3. Upload `index.html`, `style.css`, and `script.js` to the repository root.
4. In the repository, open Settings -> Pages.
5. Under Build and deployment, select Deploy from a branch.
6. Choose `main` and `/(root)`, then Save.
7. Wait for GitHub Pages to publish. Your address will look like:
   https://YOUR-USERNAME.github.io/photo-download/

After publishing, edit the canonical URL in `index.html` to your actual GitHub Pages address.

## Help Google discover it
1. Open Google Search Console: https://search.google.com/search-console/
2. Add your published website URL as a URL-prefix property.
3. Verify ownership using one of the methods Google offers (HTML file upload is not always convenient for GitHub Pages; use the HTML meta tag method if offered, adding Google's exact verification tag inside `<head>`).
4. Use URL Inspection to request indexing for your home page.
5. Keep the website public and useful. Indexing is not guaranteed and can take days or longer.

## Important limitations
- A static website cannot force another website to allow image downloads. Many sites block cross-origin requests (CORS), so the URL download button may open the image in a new tab for manual saving.
- Paste a direct image URL, not a normal webpage URL.
- Only download/use images when you have permission or the licence allows it.
- The gallery uses sample image URLs hosted by Unsplash. Review the relevant Unsplash licence and image terms before commercial use.
- This project does not store uploaded files or provide a server-side proxy. A backend would be needed for reliable downloads from hosts that block browser access.
