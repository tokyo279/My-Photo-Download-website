const photos = [
  {title:"Mountain lake",category:"Nature",tags:"mountain lake water landscape",url:"https://images.unsplash.com/photo-1470770841072-f978cf4d019e?w=900&auto=format&fit=crop&q=85"},
  {title:"Green forest",category:"Nature",tags:"forest trees green nature",url:"https://images.unsplash.com/photo-1448375240586-882707db888b?w=900&auto=format&fit=crop&q=85"},
  {title:"Ocean view",category:"Travel",tags:"ocean sea beach travel",url:"https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=900&auto=format&fit=crop&q=85"},
  {title:"City architecture",category:"Architecture",tags:"city building architecture urban",url:"https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=900&auto=format&fit=crop&q=85"},
  {title:"Desert road",category:"Travel",tags:"desert road travel adventure",url:"https://images.unsplash.com/photo-1509316785289-025f5b846b35?w=900&auto=format&fit=crop&q=85"},
  {title:"Modern building",category:"Architecture",tags:"modern building architecture",url:"https://images.unsplash.com/photo-1487958449943-2429e8be8625?w=900&auto=format&fit=crop&q=85"},
  {title:"Coffee moment",category:"Lifestyle",tags:"coffee lifestyle cup",url:"https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=900&auto=format&fit=crop&q=85"},
  {title:"Flowers",category:"Nature",tags:"flowers plants garden nature",url:"https://images.unsplash.com/photo-1490750967868-88aa4486c946?w=900&auto=format&fit=crop&q=85"},
  {title:"City street",category:"Travel",tags:"street city travel",url:"https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=900&auto=format&fit=crop&q=85"}
];

const grid = document.getElementById("photo-grid");
const search = document.getElementById("search");
const filters = document.getElementById("filters");
let activeCategory = "All";

function safeName(name){return (name || "photo").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"") || "photo";}
function showToast(message){
  const toast=document.getElementById("toast");
  toast.textContent=message;toast.classList.add("show");
  clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>toast.classList.remove("show"),3500);
}
function renderGallery(){
  const term=search.value.trim().toLowerCase();
  const visible=photos.filter(p=>(activeCategory==="All"||p.category===activeCategory) &&
    (p.title+" "+p.category+" "+p.tags).toLowerCase().includes(term));
  grid.innerHTML="";
  if(!visible.length){grid.innerHTML='<div class="empty-state">No photos found. Try another search.</div>';return;}
  visible.forEach(photo=>{
    const card=document.createElement("article");card.className="photo-card";
    const img=document.createElement("img");img.src=photo.url;img.alt=photo.title;img.loading="lazy";
    img.onerror=()=>{img.alt="Image could not be loaded";};
    const info=document.createElement("div");info.className="photo-info";
    const text=document.createElement("div");
    const title=document.createElement("h3");title.textContent=photo.title;
    const category=document.createElement("p");category.textContent=photo.category;
    text.append(title,category);
    const button=document.createElement("button");button.className="card-download";button.textContent="Download ↓";
    button.addEventListener("click",()=>downloadImage(photo.url,photo.title));
    info.append(text,button);card.append(img,info);grid.append(card);
  });
}
async function downloadImage(url,name){
  try{
    const response=await fetch(url,{mode:"cors"});
    if(!response.ok) throw new Error("Image request failed");
    const blob=await response.blob();
    if(!blob.type.startsWith("image/")) throw new Error("The link did not return an image");
    const objectUrl=URL.createObjectURL(blob);
    const a=document.createElement("a");a.href=objectUrl;a.download=safeName(name)+".jpg";
    document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(objectUrl),1500);
    showToast("Your download should start now.");
  }catch(error){
    showToast("This image host blocks direct downloads. Opening the image so you can save it manually.");
    window.open(url,"_blank","noopener,noreferrer");
  }
}
filters.addEventListener("click",event=>{
  const button=event.target.closest("button[data-category]");if(!button)return;
  activeCategory=button.dataset.category;
  filters.querySelectorAll("button").forEach(b=>b.classList.toggle("active",b===button));
  renderGallery();
});
search.addEventListener("input",renderGallery);

const urlForm=document.getElementById("url-form");
const urlInput=document.getElementById("image-url");
const urlMessage=document.getElementById("url-message");
const preview=document.getElementById("url-preview");
const previewImage=document.getElementById("preview-image");
let currentImageUrl="";
urlForm.addEventListener("submit",event=>{
  event.preventDefault();
  const value=urlInput.value.trim();
  let parsed;
  try{parsed=new URL(value);}catch{urlMessage.textContent="Please enter a valid image URL.";return;}
  if(!["http:","https:"].includes(parsed.protocol)){urlMessage.textContent="Please use an http or https image link.";return;}
  currentImageUrl=parsed.href;
  preview.hidden=false;urlMessage.textContent="Loading image preview...";
  previewImage.onload=()=>{urlMessage.textContent="Preview ready. You can now download the image.";};
  previewImage.onerror=()=>{urlMessage.textContent="Preview could not load. The link may not be a direct image URL or may block access.";preview.hidden=true;};
  previewImage.src=currentImageUrl;
  document.getElementById("preview-name").textContent=decodeURIComponent(parsed.pathname.split("/").pop()||"Image preview");
});
document.getElementById("url-download").addEventListener("click",()=>{
  if(currentImageUrl)downloadImage(currentImageUrl,"downloaded-image");
});
document.getElementById("year").textContent=new Date().getFullYear();
renderGallery();
